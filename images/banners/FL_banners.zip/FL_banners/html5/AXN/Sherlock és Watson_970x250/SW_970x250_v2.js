(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 970,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	manifest: [
		{src:"images/SW_s3_back2.jpg", id:"SW_s3_back2"},
		{src:"images/SW_s3_evad.png", id:"SW_s3_evad"},
		{src:"images/SW_s3_jonny.png", id:"SW_s3_jonny"},
		{src:"images/SW_s3_kedden.png", id:"SW_s3_kedden"},
		{src:"images/SW_s3_line.png", id:"SW_s3_line"},
		{src:"images/SW_s3_logo.png", id:"SW_s3_logo"},
		{src:"images/SW_s3_lucy.png", id:"SW_s3_lucy"},
		{src:"images/SW_s3_nyomozni.png", id:"SW_s3_nyomozni"},
		{src:"images/SW_s3_nyomozni2pngcopy.png", id:"SW_s3_nyomozni2pngcopy"},
		{src:"images/SW_s3_red.png", id:"SW_s3_red"},
		{src:"images/SW_s3_sherlock.png", id:"SW_s3_sherlock"}
	]
};



// symbols:



(lib.SW_s3_back2 = function() {
	this.initialize(img.SW_s3_back2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1428,250);


(lib.SW_s3_evad = function() {
	this.initialize(img.SW_s3_evad);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_jonny = function() {
	this.initialize(img.SW_s3_jonny);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_kedden = function() {
	this.initialize(img.SW_s3_kedden);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_line = function() {
	this.initialize(img.SW_s3_line);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_logo = function() {
	this.initialize(img.SW_s3_logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_lucy = function() {
	this.initialize(img.SW_s3_lucy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_nyomozni = function() {
	this.initialize(img.SW_s3_nyomozni);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_nyomozni2pngcopy = function() {
	this.initialize(img.SW_s3_nyomozni2pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_red = function() {
	this.initialize(img.SW_s3_red);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.SW_s3_sherlock = function() {
	this.initialize(img.SW_s3_sherlock);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.Tween27 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_nyomozni2pngcopy();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween26 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_nyomozni2pngcopy();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween24 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_logo();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween23 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_logo();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween22 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_red();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween21 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_red();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween20 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_line();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween19 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_line();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween18 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_evad();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween17 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_evad();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween16 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_kedden();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween15 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_kedden();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween14 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_nyomozni();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween13 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_nyomozni();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween12 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_sherlock();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween11 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_sherlock();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween10 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_jonny();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween9 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_jonny();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween8 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_lucy();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween7 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_lucy();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween4 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_back2();
	this.instance.setTransform(-714,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-714,-125,1428,250);


(lib.Tween3 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.SW_s3_back2();
	this.instance.setTransform(-714,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-714,-125,1428,250);


// stage content:
(lib.SW_970x250_v2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// kedden
	this.instance = new lib.Tween15("synched",0);
	this.instance.setTransform(485,125);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween16("synched",0);
	this.instance_1.setTransform(485,125);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({_off:true,alpha:1},40).wait(136));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},40).wait(51).to({startPosition:0},0).wait(28).to({startPosition:0},0).to({x:700},9).wait(22).to({startPosition:0},0).to({alpha:0},5).to({_off:true},1).wait(20));

	// line
	this.instance_2 = new lib.Tween19("synched",0);
	this.instance_2.setTransform(1053,125);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween20("synched",0);
	this.instance_3.setTransform(485,125);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({_off:false},0).to({_off:true,x:485},5).wait(171));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(59).to({_off:false},5).wait(35).to({startPosition:0},0).wait(51).to({startPosition:0},0).wait(28).to({startPosition:0},0).to({y:135,alpha:0},5).to({_off:true},1).wait(51));

	// nyomozni
	this.instance_4 = new lib.Tween13("synched",0);
	this.instance_4.setTransform(485,269);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween14("synched",0);
	this.instance_5.setTransform(485,125);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({_off:true,y:125},10,cjs.Ease.get(1)).wait(181));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(44).to({_off:false},10,cjs.Ease.get(1)).wait(45).to({startPosition:0},0).wait(51).to({startPosition:0},0).wait(28).to({startPosition:0},0).to({y:155,alpha:0},5).to({_off:true},1).wait(51));

	// evad
	this.instance_6 = new lib.Tween17("synched",0);
	this.instance_6.setTransform(485,261);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween18("synched",0);
	this.instance_7.setTransform(485,125);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(44).to({_off:false},0).to({_off:true,y:125},10,cjs.Ease.get(1)).wait(181));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(44).to({_off:false},10,cjs.Ease.get(1)).wait(45).to({startPosition:0},0).wait(51).to({startPosition:0},0).wait(28).to({startPosition:0},0).to({y:155,alpha:0},5).to({_off:true},1).wait(51));

	// sherlock
	this.instance_8 = new lib.Tween11("synched",0);
	this.instance_8.setTransform(485,341);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween12("synched",0);
	this.instance_9.setTransform(485,125);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(34).to({_off:false},0).to({_off:true,y:125},20,cjs.Ease.get(1)).wait(181));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(34).to({_off:false},20,cjs.Ease.get(1)).wait(45).to({startPosition:0},0).wait(51).to({startPosition:0},0).wait(28).to({startPosition:0},0).to({y:105,alpha:0},5).to({_off:true},1).wait(51));

	// jonny
	this.instance_10 = new lib.Tween9("synched",0);
	this.instance_10.setTransform(485,69);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween10("synched",0);
	this.instance_11.setTransform(485,125);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(34).to({_off:false},0).to({_off:true,y:125},10,cjs.Ease.get(1)).wait(191));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(34).to({_off:false},10,cjs.Ease.get(1)).wait(55).to({startPosition:0},0).wait(51).to({startPosition:0},0).wait(28).to({startPosition:0},0).to({y:95,alpha:0},5).to({_off:true},1).wait(51));

	// lucy
	this.instance_12 = new lib.Tween7("synched",0);
	this.instance_12.setTransform(485,69);
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween8("synched",0);
	this.instance_13.setTransform(485,125);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(29).to({_off:false},0).to({_off:true,y:125},10,cjs.Ease.get(1)).wait(196));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(29).to({_off:false},10,cjs.Ease.get(1)).wait(60).to({startPosition:0},0).wait(51).to({startPosition:0},0).wait(28).to({startPosition:0},0).to({y:95,alpha:0},5).to({_off:true},1).wait(51));

	// logo
	this.instance_14 = new lib.Tween23("synched",0);
	this.instance_14.setTransform(485,125);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween24("synched",0);
	this.instance_15.setTransform(485,125);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(74).to({_off:false},0).to({_off:true,alpha:1},10).wait(151));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(74).to({_off:false},10).wait(15).to({startPosition:0},0).wait(51).to({startPosition:0},0).wait(28).to({startPosition:0},0).to({alpha:0},10).to({_off:true},1).wait(46));

	// red
	this.instance_16 = new lib.Tween21("synched",0);
	this.instance_16.setTransform(485,125);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween22("synched",0);
	this.instance_17.setTransform(485,125);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(74).to({_off:false},0).to({_off:true,alpha:1},10,cjs.Ease.get(-1)).wait(151));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(74).to({_off:false},10,cjs.Ease.get(-1)).to({y:142,alpha:0},94).to({_off:true},1).wait(56));

	// Layer 1
	this.instance_18 = new lib.SW_s3_nyomozni2pngcopy();

	this.instance_19 = new lib.Tween26("synched",0);
	this.instance_19.setTransform(485,125);
	this.instance_19._off = true;

	this.instance_20 = new lib.Tween27("synched",0);
	this.instance_20.setTransform(1357,125);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_18}]}).to({state:[{t:this.instance_19}]},19).to({state:[{t:this.instance_20}]},10).to({state:[{t:this.instance_20}]},185).to({state:[{t:this.instance_20}]},5).to({state:[{t:this.instance_20}]},15).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(19).to({_off:false},0).to({_off:true,x:1357},10,cjs.Ease.get(-1)).wait(206));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(19).to({_off:false},10,cjs.Ease.get(-1)).wait(185).to({startPosition:0},0).to({x:485},5).wait(15).to({startPosition:0},0).wait(1));

	// back
	this.instance_21 = new lib.SW_s3_back2();
	this.instance_21.setTransform(-458,0);

	this.instance_22 = new lib.Tween3("synched",0);
	this.instance_22.setTransform(256,125);
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween4("synched",0);
	this.instance_23.setTransform(714,125);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21}]}).to({state:[{t:this.instance_22}]},19).to({state:[{t:this.instance_23}]},10).to({state:[{t:this.instance_23}]},180).to({state:[{t:this.instance_23}]},10).to({state:[{t:this.instance_23}]},15).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(19).to({_off:false},0).to({_off:true,x:714},10,cjs.Ease.get(1)).wait(206));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(19).to({_off:false},10,cjs.Ease.get(1)).wait(180).to({startPosition:0},0).to({x:256},10,cjs.Ease.get(-1)).wait(15).to({startPosition:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(27,125,1428,250);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;