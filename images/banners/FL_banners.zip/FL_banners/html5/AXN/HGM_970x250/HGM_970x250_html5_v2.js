(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 970,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	manifest: [
		{src:"images/a22ora.png", id:"a22ora"},
		{src:"images/a2evad.png", id:"a2evad"},
		{src:"images/back.jpg", id:"back"},
		{src:"images/back2.jpg", id:"back2"},
		{src:"images/gyilkossagot.png", id:"gyilkossagot"},
		{src:"images/h22.png", id:"h22"},
		{src:"images/hetfo.png", id:"hetfo"},
		{src:"images/hogyan.png", id:"hogyan"},
		{src:"images/legjobb.png", id:"legjobb"},
		{src:"images/logo.png", id:"logo"},
		{src:"images/megegy.png", id:"megegy"},
		{src:"images/usszunk.png", id:"usszunk"},
		{src:"images/viola.png", id:"viola"}
	]
};



// symbols:



(lib.a22ora = function() {
	this.initialize(img.a22ora);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.a2evad = function() {
	this.initialize(img.a2evad);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.back = function() {
	this.initialize(img.back);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.back2 = function() {
	this.initialize(img.back2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.gyilkossagot = function() {
	this.initialize(img.gyilkossagot);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.h22 = function() {
	this.initialize(img.h22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.hetfo = function() {
	this.initialize(img.hetfo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.hogyan = function() {
	this.initialize(img.hogyan);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.legjobb = function() {
	this.initialize(img.legjobb);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.megegy = function() {
	this.initialize(img.megegy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.usszunk = function() {
	this.initialize(img.usszunk);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.viola = function() {
	this.initialize(img.viola);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


(lib.Tween24 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.h22();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween23 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.h22();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween22 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.logo();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween21 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.logo();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween20 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.legjobb();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween19 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.legjobb();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween18 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.viola();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween17 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.viola();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween16 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.a22ora();
	this.instance.setTransform(-485,-125);

	this.instance_1 = new lib.a22ora();
	this.instance_1.setTransform(-485,-125);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween15 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.a22ora();
	this.instance.setTransform(-485,-125);

	this.instance_1 = new lib.a22ora();
	this.instance_1.setTransform(-485,-125);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween14 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.hetfo();
	this.instance.setTransform(-485,-125);

	this.instance_1 = new lib.hetfo();
	this.instance_1.setTransform(-485,-125);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween13 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.hetfo();
	this.instance.setTransform(-485,-125);

	this.instance_1 = new lib.hetfo();
	this.instance_1.setTransform(-485,-125);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween12 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.a2evad();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween11 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.a2evad();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween10 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.gyilkossagot();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween8 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.megegy();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween6 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.usszunk();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween4 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.hogyan();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween2 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.back();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


(lib.Tween1 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.back();
	this.instance.setTransform(-485,-125);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-485,-125,970,250);


// stage content:
(lib.HGM_970x250_html5_v2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// logo
	this.instance = new lib.Tween21("synched",0);
	this.instance.setTransform(485.5,125);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween22("synched",0);
	this.instance_1.setTransform(485.5,125);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(151).to({_off:false},0).to({_off:true,alpha:1},20,cjs.Ease.get(-1)).wait(158));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(151).to({_off:false},20,cjs.Ease.get(-1)).wait(126).to({startPosition:0},0).to({alpha:0},15,cjs.Ease.get(-1)).to({_off:true},1).wait(16));

	// h22
	this.instance_2 = new lib.Tween23("synched",0);
	this.instance_2.setTransform(485,125);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween24("synched",0);
	this.instance_3.setTransform(485,125);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(171).to({_off:false},0).to({_off:true,alpha:1},13,cjs.Ease.get(-1)).wait(145));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(171).to({_off:false},13,cjs.Ease.get(-1)).wait(78).to({startPosition:0},0).to({alpha:0},20,cjs.Ease.get(-1)).to({_off:true},1).wait(46));

	// 22ora
	this.instance_4 = new lib.Tween15("synched",0);
	this.instance_4.setTransform(735,125);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween16("synched",0);
	this.instance_5.setTransform(485,125);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(106).to({_off:false},0).to({_off:true,x:485,alpha:1},10,cjs.Ease.get(1)).wait(213));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(106).to({_off:false},10,cjs.Ease.get(1)).wait(35).to({startPosition:0},0).to({x:385,alpha:0},5,cjs.Ease.get(-1)).to({_off:true},1).wait(172));

	// hetfo
	this.instance_6 = new lib.Tween13("synched",0);
	this.instance_6.setTransform(735,125);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween14("synched",0);
	this.instance_7.setTransform(485,125);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(59).to({_off:false},0).to({_off:true,x:485,alpha:1},10,cjs.Ease.get(1)).wait(260));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(59).to({_off:false},10,cjs.Ease.get(1)).wait(35).to({startPosition:0},0).to({x:385,alpha:0},5,cjs.Ease.get(-1)).to({_off:true},1).wait(219));

	// viola
	this.instance_8 = new lib.Tween17("synched",0);
	this.instance_8.setTransform(485.5,165);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween18("synched",0);
	this.instance_9.setTransform(485.5,120);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(39).to({_off:false},0).to({_off:true,y:120,alpha:1},5,cjs.Ease.get(1)).wait(285));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(39).to({_off:false},5,cjs.Ease.get(1)).wait(223).to({startPosition:0},0).to({alpha:0},20,cjs.Ease.get(-1)).to({_off:true},1).wait(41));

	// legjobb
	this.instance_10 = new lib.Tween19("synched",0);
	this.instance_10.setTransform(485.5,165);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween20("synched",0);
	this.instance_11.setTransform(485.5,120);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(41).to({_off:false},0).to({_off:true,y:120,alpha:1},5,cjs.Ease.get(1)).wait(283));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(41).to({_off:false},5,cjs.Ease.get(1)).wait(226).to({startPosition:0},0).to({alpha:0},20,cjs.Ease.get(-1)).to({_off:true},1).wait(36));

	// 2evad
	this.instance_12 = new lib.Tween11("synched",0);
	this.instance_12.setTransform(485,125);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween12("synched",0);
	this.instance_13.setTransform(485,125);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(21).to({_off:false},0).to({_off:true,alpha:1},5,cjs.Ease.get(1)).wait(303));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(21).to({_off:false},5,cjs.Ease.get(1)).wait(231).to({startPosition:0},0).to({alpha:0},20,cjs.Ease.get(-1)).to({_off:true},1).wait(51));

	// hogyan
	this.instance_14 = new lib.Tween4("synched",0);
	this.instance_14.setTransform(465,15);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(15).to({_off:false},0).to({x:485,y:125},5,cjs.Ease.get(-1)).wait(217).to({startPosition:0},0).to({alpha:0},20,cjs.Ease.get(-1)).to({_off:true},1).wait(71));

	// usszunk
	this.instance_15 = new lib.Tween6("synched",0);
	this.instance_15.setTransform(465.5,15);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(12).to({_off:false},0).to({x:485.5,y:125},5,cjs.Ease.get(-1)).wait(225).to({startPosition:0},0).to({alpha:0},20,cjs.Ease.get(-1)).to({_off:true},1).wait(66));

	// megegy
	this.instance_16 = new lib.Tween8("synched",0);
	this.instance_16.setTransform(465.5,15);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(9).to({_off:false},0).to({x:485.5,y:125},5,cjs.Ease.get(-1)).wait(233).to({startPosition:0},0).to({alpha:0},20,cjs.Ease.get(-1)).to({_off:true},1).wait(61));

	// gyilkossagot
	this.instance_17 = new lib.Tween10("synched",0);
	this.instance_17.setTransform(466,145.6,1.165,1.165);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(18).to({_off:false},0).to({scaleX:1,scaleY:1,x:485,y:125,alpha:1},5,cjs.Ease.get(-1)).wait(229).to({startPosition:0},0).to({alpha:0},20,cjs.Ease.get(-1)).to({_off:true},1).wait(56));

	// back
	this.instance_18 = new lib.Tween1("synched",0);
	this.instance_18.setTransform(485,125);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween2("synched",0);
	this.instance_19.setTransform(485,125);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(21).to({_off:false},0).to({_off:true,alpha:1},2).wait(306));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(21).to({_off:false},2).wait(244).to({startPosition:0},0).to({alpha:0},35,cjs.Ease.get(-1)).to({_off:true},1).wait(26));

	// back2
	this.instance_20 = new lib.back2();

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(329));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(485,125,970,250);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;